n = input("Please enter a number: ")
print(type(n), n)

n = int(n)
print(type(n), n)

n = float(n)
print(type(n), n)

s = "This is a string"
parts = s.split(" ")
print(parts)

parts = s.split("is")
print(parts)

a = 13 % 2  # find out modul
print(a)

# line comment
# other line comment

"""
This is a block of comments. 
I usually use this when I have a longer text to explain 
what the code does. 
"""
