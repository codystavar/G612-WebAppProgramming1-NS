value = input("Please enter a value: ")
print(type(value), value)

value = int(value)  # numar intreg
print(type(value), value)

value = float(value)  # numar zecimal
print(type(value), value)
