a = 10

dictionary = {}
dictionary["cheia1"] = "valoarea1"
dictionary["cheia2"] = "valoarea2"

print(dictionary)

"""
{
"cheia1": "valoarea1",
"cheia2": "valoarea2"
}
"""
import os