# reading input
n = input("Please enter a number: ")
print(type(n), n)

n = int(n)
print(type(n), n)

n = float(n)
print(type(n), n)

# modulo
rest = 12 % 2
print(rest)

# split
s = "This is a string"
parts = s.split(" ")
print(parts)

parts = s.split("is")
print(parts)