# rau-web-programming-1

## Cum va luati codul 
- aveti un buton la voi pe repo-ul pe care l-ati forkuit, **Fetch Upstream**
- il apasati, apoi **Fetch and merge**
- dupa, mergeti in editorul vostru (Pycharm, vscode) si rulati comanda ```git pull``` intr-un terminal, sau butonul de **update project**
- daca aveti probleme, imi scrieti pe Teams


## Cum lucram cu tema
- va trebui sa faceti **fork** la acest repository (dreapta-sus)
- asta va crea o copie locala la voi in contul de git a acestui repository la momentul de timp la care ati dat fork
- in contul vostru de github, veti avea deci un repository **rau-mas-ai**
- in momentul in care vom incarca cod, va trebui sa mergeti in repository-ul vostru, pe site-ul github si sa folositi butonul de **Fetch upstream**
- asta va lua modificarile noastre si le va combina cu ceea ce ati facut voi deja
- ca sa puteti lucra pe repository folosind pycharm sau vscode, va trebui sa **clonati** repository-ul nou creat la voi in contul de github pe masina local (laptop/PC)
- puteti face asta folosind comanda ```git clone [link repository]```, sau, in pycharm, cand creati un nou proiect, folositi butonul **Get from VCS**
- dupa ce veti termina de lucrat va trebui sa faceti commit + push pt a va salva modificarile
- pentru asta, puteti folosi comenzile ```git add <nume_fisier>``` (sau ```git add .``` pentru a adauga toate fisierele)  ```git commit -m "Mesaj de comit"``` si ```git push origin <branch>```

## Resurse utile
- git cheat sheet (https://www.atlassian.com/git/tutorials/atlassian-git-cheatsheet)
