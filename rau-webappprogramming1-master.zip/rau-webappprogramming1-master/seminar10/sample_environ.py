import os

my_variable = os.environ["MY_SAMPLE_VARIABLE"]
print(my_variable)
